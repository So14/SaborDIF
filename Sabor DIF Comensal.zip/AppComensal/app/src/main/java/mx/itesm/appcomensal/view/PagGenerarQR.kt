package mx.itesm.appcomensal.view

import android.content.SharedPreferences
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.ImageView
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import mx.itesm.appcomensal.R
import mx.itesm.appcomensal.databinding.ActivityPagGenerarQrBinding

class PagGenerarQR : AppCompatActivity() {

    //binding
    private lateinit var binding: ActivityPagGenerarQrBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //binding
        binding = ActivityPagGenerarQrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var codigoQR: ImageView = findViewById(R.id.codigoQR)

        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val savedQrCodeResult: String? = sharedPreferences.getString("qr_code_result", "")
        // Ahora savedQrCodeResult contiene el valor del código QR guardado localmente


        val darID = findViewById<TextView>(R.id.avisoID)

        try {
            var barcodeEncoder: BarcodeEncoder = BarcodeEncoder()
            var bitmap: Bitmap = barcodeEncoder.encodeBitmap(
                savedQrCodeResult.toString(),
                BarcodeFormat.QR_CODE,
                700,
                700
            )
            codigoQR.setImageBitmap(bitmap)
            darID.visibility = TextView.VISIBLE
            binding.avisoID.setText("Su ID es: " + savedQrCodeResult)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}