package mx.itesm.appcomensal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.itesm.appcomensal.R

class PagAviso : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pag_aviso)
    }
}