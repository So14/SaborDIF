package mx.itesm.appcomensal.viewmodel

import mx.itesm.appcomensal.model.ListaServicioAPI
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.util.Log
import androidx.lifecycle.ViewModel
import mx.itesm.appcomensal.model.Encuesta
import mx.itesm.appcomensal.model.Message

class RegistrarEncuestaVM : ViewModel() {

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("http://34.236.3.58:3000/api/encuesta/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    }
    private val posterarAPI by lazy {
        retrofit.create(ListaServicioAPI::class.java)
    }

    fun registrarEncuesta(encuesta: Encuesta) {
        val call = posterarAPI.registrarEncuesta(encuesta)
        call.enqueue(object : Callback<Message> {
            override fun onResponse(call: Call<Message>, response: Response<Message>) {
                if (response.isSuccessful) {
                    println("Dependencia creado exitosamente: ${response.body()}")
                    Log.d("API_TEST", "Encuesta registrada exitosamente: ${response.body()}")
                } else {
                    Log.e("API_TEST", "FAILED")
                }
            }
            override fun onFailure(call: Call<Message>, t: Throwable) {
                println("ERROR: ${t.localizedMessage}")
                Log.e("API_TEST", "FAILED ${t.localizedMessage}")
            }
        })
    }
}