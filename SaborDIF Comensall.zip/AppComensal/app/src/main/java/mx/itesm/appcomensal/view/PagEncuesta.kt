package mx.itesm.appcomensal.view

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import mx.itesm.appcomensal.R
import mx.itesm.appcomensal.databinding.ActivityPagEncuestaBinding
import mx.itesm.appcomensal.model.Comedor
import mx.itesm.appcomensal.model.Encuesta
import mx.itesm.appcomensal.viewmodel.ComedorVM
import mx.itesm.appcomensal.viewmodel.RegistrarEncuestaVM

class PagEncuesta : AppCompatActivity() {

    //Encuesta
    var S = 0
    var T = 0
    var H = 0
    var A = 0
    var C = 0

    //Iniciar binding
    private lateinit var binding: ActivityPagEncuestaBinding

    //Declarar al ViewModel de Encuesta
  //  var registrarEncuestaVM: RegistrarEncuestaVM = RegistrarEncuestaVM()

    val comedorVm: ComedorVM = ComedorVM()
    val encuestaVm = RegistrarEncuestaVM()
    val listaComedores = mutableListOf<String>()
    val mapaComedores: MutableMap<String, Int> = mutableMapOf()
    //Declarar al viewModel de Comedor

        //ViewModel

    private lateinit var viewEncuesta: RegistrarEncuestaVM

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Verificar si la aplicación tiene acceso a Internet
        if (!isInternetAvailable()) {
            // Mostrar un AlertDialog indicando que no hay acceso a Internet
            showNoInternetDialog()
        }

        //binding
        binding = ActivityPagEncuestaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val spComedoresMenu: Spinner = findViewById(R.id.comedores)


        comedorVm.descargarNombresComedor { comedores ->
            if(comedores != null){
                Log.d("API", "encuesta ${comedores}", )
                for (comedor in comedores) {
                    listaComedores.add(comedor.nombreComedor)
                    mapaComedores[comedor.nombreComedor] = comedor.IdComedor
                }
                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listaComedores)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
                spComedoresMenu.adapter = adapter

            }
        }
        viewEncuesta = ViewModelProvider(this).get(RegistrarEncuestaVM::class.java)



//        Spinner Adapter

        val miLista = ArrayList<Comedor>()


        //Sabor
        val seekBarS = findViewById<SeekBar>(R.id.seekBarS)
        val progressTextViewS = findViewById<TextView>(R.id.progressS)

        //tiempo
        val seekBarT = findViewById<SeekBar>(R.id.seekBarT)
        val progressTextViewT = findViewById<TextView>(R.id.progressT)

        //atención
        val seekBarA = findViewById<SeekBar>(R.id.seekBarA)
        val progressTextViewA = findViewById<TextView>(R.id.progressA)

        //Comedor
        val seekBarC = findViewById<SeekBar>(R.id.seekBarC)
        val progressTextViewC = findViewById<TextView>(R.id.progressC)

        //higiene
        val seekBarH = findViewById<SeekBar>(R.id.seekBarH)
        val progressTextViewH = findViewById<TextView>(R.id.progressH)

        //sabor
        seekBarS.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Actualizar el texto del TextView con el progreso actual del SeekBar
                progressTextViewS.text = "Puntuación: $progress"
                S = progress
                progressTextViewS.visibility = TextView.VISIBLE
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario comienza a arrastrar el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario deja de arrastrar el SeekBar
            }
        })

        //tiempo
        seekBarT.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Actualizar el texto del TextView con el progreso actual del SeekBar
                progressTextViewT.text = "Puntuación: $progress"
                T = progress
                progressTextViewT.visibility = TextView.VISIBLE
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario comienza a arrastrar el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario deja de arrastrar el SeekBar
            }
        })

        //atencion
        seekBarA.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Actualizar el texto del TextView con el progreso actual del SeekBar
                progressTextViewA.text = "Puntuación: $progress"
                A = progress
                progressTextViewA.visibility = TextView.VISIBLE
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario comienza a arrastrar el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario deja de arrastrar el SeekBar
            }
        })

        //comedor
        seekBarC.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Actualizar el texto del TextView con el progreso actual del SeekBar
                progressTextViewC.text = "Puntuación: $progress"
                C = progress
                progressTextViewC.visibility = TextView.VISIBLE
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario comienza a arrastrar el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario deja de arrastrar el SeekBar
            }
        })

        //higiene
        seekBarH.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Actualizar el texto del TextView con el progreso actual del SeekBar
                H = progress
                progressTextViewH.text = "Puntuación: $progress"
                progressTextViewH.visibility = TextView.VISIBLE
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario comienza a arrastrar el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Método llamado cuando el usuario deja de arrastrar el SeekBar
            }
        })

        // Boton para enviar datos y regresar pagina
        binding.btnEnviarDatos.setOnClickListener {
            val comedor = binding.comedores.selectedItem.toString()
            Log.e("BOTON", "${mapaComedores[comedor]}")
            val idComedor = mapaComedores[comedor]

            if (S <= 0 || A <= 0 || T <= 0 || C <= 0 || H <= 0 || idComedor == null) {
                // Al menos uno de los valores es nulo, mostrar el AlertDialog
                val valoresnull = AlertDialog.Builder(this, R.style.AlertDialogCustom)
                valoresnull.setTitle("Advertencia")
                    .setMessage("Uno de los valores de la escuesta es nulo. \n\nPor favor, verifica los valores.")
                    .setPositiveButton("OK") { dialog, _ ->
                        // Cerrar el AlertDialog
                        dialog.dismiss()
                    }
                    .show()
            } else if (idComedor != null) {
                // Todos los valores son no nulos, continuar con el registro de la encuesta
                encuestaVm.registrarEncuesta(Encuesta(idComedor, S, T, A, C, H ))

                // Mostrar AlertDialog indicando que la encuesta se envió con éxito
                val builder = AlertDialog.Builder(this, R.style.AlertDialogCustom)
                builder.setTitle("Éxito")
                    .setMessage("La encuesta se envió con éxito.")
                    .setPositiveButton("OK") { dialog, _ ->
                        // Cerrar el AlertDialog y comenzar la actividad MainActivity
                        dialog.dismiss()
                        val enviar = Intent(this, MainActivity::class.java)
                        startActivity(enviar)
                    }
                    .show()
            }
        }
    }

    private fun isInternetAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }

    private fun showNoInternetDialog() {
        val builder = AlertDialog.Builder(this, R.style.AlertDialogCustom)
        builder.setTitle("Sin conexión a Internet")
            .setMessage("La aplicación no tiene acceso a Internet.\n\nPor favor, verifica tu conexión.")
            .setPositiveButton("OK") { dialog, _ ->
                // Cerrar el AlertDialog y, opcionalmente, salir de la aplicación
                dialog.dismiss()
                finish() // Esto cerrará la aplicación
            }
            .show()
    }

}
