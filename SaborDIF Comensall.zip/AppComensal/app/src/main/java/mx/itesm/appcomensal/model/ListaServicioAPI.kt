package mx.itesm.appcomensal.model


import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface ListaServicioAPI {
    @POST("registrar")
    fun registrarEncuesta(@Body encuesta: Encuesta): Call<Message>
}