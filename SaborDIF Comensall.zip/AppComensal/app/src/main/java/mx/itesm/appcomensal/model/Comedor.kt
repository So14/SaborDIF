package mx.itesm.appcomensal.model

import com.google.gson.annotations.SerializedName

data class Comedor(
    @SerializedName("NombreComedor")
    var nombreComedor: String,
    @SerializedName("IdComedor")
    var IdComedor: Int
)
