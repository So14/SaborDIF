package mx.itesm.appcomensal.view

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import mx.itesm.appcomensal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //Iniciar binding
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Boton para leer el codigo del ID del comensal
        binding.btnLeerQR.setOnClickListener {
            val idqr = Intent(this, PagLeerQR::class.java)
            startActivity(idqr)
        }
        // Boton para generar el codigo QR en base a su ID
        binding.btnGenQR.setOnClickListener {
            val genQR = Intent(this, PagGenerarQR::class.java)
            startActivity(genQR)
        }

        // Boton para direccionar a los comedores comunitarios
        binding.btngooglemap.setOnClickListener {

            // Verificar si la aplicación tiene acceso a Internet
            if (!isInternetAvailable()) {
                // Mostrar un AlertDialog indicando que no hay acceso a Internet
                showNoInternetDialog()
            }

            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://www.google.com/maps/d/u/1/edit?mid=1mPXVsc0gXxL5diInaNvG9tZfGEKKLZg&usp=sharing")
            startActivity(openURL)
        }

        // Boton para hacer la encuesta
        binding.btnEnc.setOnClickListener {
            val encuesta = Intent(this, PagEncuesta::class.java)
            startActivity(encuesta)
        }

        // Boton para los derechos y obligaciones
        binding.btnAviso.setOnClickListener {
            val aviso = Intent(this, PagAviso::class.java)
            startActivity(aviso)
        }
    }
    private fun isInternetAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }

    private fun showNoInternetDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Sin conexión a Internet")
            .setMessage("La aplicación no tiene acceso a Internet. Por favor, verifica tu conexión.")
            .setPositiveButton("OK") { dialog, _ ->
                // Cerrar el AlertDialog y, opcionalmente, salir de la aplicación
                dialog.dismiss()
                finish() // Esto cerrará la aplicación
            }
            .show()
    }

}