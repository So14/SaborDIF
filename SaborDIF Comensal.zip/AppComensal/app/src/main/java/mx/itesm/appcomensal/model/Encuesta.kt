package mx.itesm.appcomensal.model

import com.google.gson.annotations.SerializedName

data class Encuesta(
    @SerializedName("IdComedor")
    val IdComedor: Int,
    @SerializedName("sabor")
    val sabor: Int,
    @SerializedName("tiempo")
    val tiempo: Int,
    @SerializedName("atencion")
    val atencion: Int,
    @SerializedName("lugar")
    val lugar: Int,
    @SerializedName("higiene")
    val higiene: Int,
)
