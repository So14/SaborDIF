package mx.itesm.appcomensal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import mx.itesm.appcomensal.R
import mx.itesm.appcomensal.viewmodel.ComedorVM

class PagAviso : AppCompatActivity() {
    var comedorVm = ComedorVM()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pag_aviso)
        comedorVm.descargarNombresComedor { comedors ->
            if(comedors != null){
                Log.d("API", "aviso de privacidad${comedors}", )
            }
        }
    }
}