package mx.itesm.appcomensal.view

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.gms.common.moduleinstall.InstallStatusListener
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate.InstallState.STATE_CANCELED
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate.InstallState.STATE_COMPLETED
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate.InstallState.STATE_FAILED
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import mx.itesm.appcomensal.databinding.ActivityPagLeerQrBinding
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import mx.itesm.appcomensal.R


class PagLeerQR : AppCompatActivity() {

    //Iniciar binding y el Scan
    private lateinit var binding: ActivityPagLeerQrBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPagLeerQrBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_pag_leer_qr)
        setContentView(binding.root)

        validarModulo()
    }

    private fun validarModulo() {
        val moduleInstallClient = ModuleInstall.getClient(this)
        val optionalModuleApi = GmsBarcodeScanning.getClient(this)

        moduleInstallClient
            .areModulesAvailable(optionalModuleApi)
            .addOnSuccessListener {
                if (it.areModulesAvailable()) {
                    println("Si está instalado")
                    leerQR()
                } else {
                    println("No está instalado")
                    binding.imgCarga.visibility = View.VISIBLE
                    instalarModulo()
                }
            }
            .addOnFailureListener {
                println("Error al verificar módulo")
            }
    }

    private fun instalarModulo() {
        val moduleInstallClient = ModuleInstall.getClient(this)
        val optionalModuleApi = GmsBarcodeScanning.getClient(this)

        val moduleInstallRequest =
            ModuleInstallRequest.newBuilder()
                .addApi(optionalModuleApi)
                .setListener(listener)
                .build()

        moduleInstallClient
            .installModules(moduleInstallRequest)
            .addOnSuccessListener {
                if (it.areModulesAlreadyInstalled()) {
                    // Modules are already installed when the request is sent.
                    println("I N S T A L A N D O ......")
                }
            }
            .addOnFailureListener {
                println("NO SE PUEDE INSTALAR")
            }
    }

    private fun leerQR() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_QR_CODE,
                Barcode.FORMAT_ALL_FORMATS
            )
            .enableAutoZoom()
            .build()

        val scanner = GmsBarcodeScanning.getClient(this, options)
        val vista = findViewById<TextView>(R.id.idCliente)

        binding.ScanQR.setOnClickListener {
            scanner.startScan()
                .addOnSuccessListener { barcode ->
                    val rawValue: String? = barcode.rawValue
                    vista.visibility = TextView.VISIBLE
                    binding.idCliente.setText("Su ID es: " + rawValue)

                    val qrCodeResult = rawValue

                    // Guardar el resultado en las preferencias compartidas
                    val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
                    val editor: SharedPreferences.Editor = sharedPreferences.edit()
                    editor.putString("qr_code_result", qrCodeResult)
                    editor.apply()

                    // Mostrar un mensaje de éxito
                    Toast.makeText(this, "Código QR guardado localmente", Toast.LENGTH_SHORT).show()
                }
                .addOnCanceledListener {
                    //Se canceló la tarea
                }
                .addOnFailureListener { e ->
                    binding.idCliente.text = "Error: ${e.message}"
                }
        }
    }

    inner class ModuleInstallProgressListener : InstallStatusListener {
        override fun onInstallStatusUpdated(update: ModuleInstallStatusUpdate) {
            // Progress info is only set when modules are in the progress of downloading.
            update.progressInfo?.let {
                val progress = (it.bytesDownloaded * 100 / it.totalBytesToDownload).toInt()
                // Set the progress for the progress bar.
                //progressBar.setProgress(progress)
                println(progress)
                if(progress == 100)
                {
                    binding.imgCarga.visibility = View.INVISIBLE

                }
            }

            if (isTerminateState(update.installState)) {
                //moduleInstallClient.unregisterListener(this)
            }
        }

        fun isTerminateState(@ModuleInstallStatusUpdate.InstallState state: Int): Boolean {
            return state == STATE_CANCELED || state == STATE_COMPLETED || state == STATE_FAILED
        }
    }

    val listener = ModuleInstallProgressListener()
}